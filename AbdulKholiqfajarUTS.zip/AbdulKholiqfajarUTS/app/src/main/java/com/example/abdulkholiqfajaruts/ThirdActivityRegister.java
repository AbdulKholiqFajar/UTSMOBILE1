package com.example.abdulkholiqfajaruts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.abdulkholiqfajaruts.R;

public class ThirdActivityRegister  extends AppCompatActivity
{
    Button btnLogin, btnRegister;
    EditText username, password, name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_main);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        name = (EditText) findViewById(R.id.name);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String isUsername = username.getText().toString();
                String isPassword = password.getText().toString();
                String isName = name.getText().toString();
                if (isUsername.matches("") && isPassword.matches("") && isName.matches("")) {
                    Toast.makeText(ThirdActivityRegister.this, "Data Tidak Valid Wajib Diisi", Toast.LENGTH_SHORT).show();
                    return;
                }else {
                    String strUsername = "Username = " + isUsername;
                    String strName = "Nama = " + isName;

                    Intent intent = new Intent(ThirdActivityRegister.this, SecondActivityProfile.class);
                    intent.putExtra("Username", strUsername);
                    intent.putExtra("Nama", strName);
                    startActivity(intent);
                }

            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ThirdActivityRegister.this, MainActivity.class);
                startActivity(intent);

            }
        });
    }
}
