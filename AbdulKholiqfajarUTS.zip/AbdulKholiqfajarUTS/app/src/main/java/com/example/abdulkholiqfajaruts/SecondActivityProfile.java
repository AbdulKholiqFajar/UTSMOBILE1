package com.example.abdulkholiqfajaruts;

import android.content.Intent;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.abdulkholiqfajaruts.R;

public class SecondActivityProfile extends AppCompatActivity
{
    TextView username, name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_main);

        username = (TextView) findViewById(R.id.text_username);
        name = (TextView) findViewById(R.id.text_name);

        Intent intent = getIntent();

        String isUsername = intent.getStringExtra("Username");
        String isName = intent.getStringExtra("Nama");

        username.setTextColor(Color.BLACK);
        username.setText(isUsername);

        name.setTextColor(Color.BLACK);
        name.setText(isName);

    }
}