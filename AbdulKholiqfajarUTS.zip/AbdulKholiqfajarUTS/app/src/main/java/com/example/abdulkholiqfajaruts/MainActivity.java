package com.example.abdulkholiqfajaruts;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.abdulkholiqfajaruts.R;

public class MainActivity extends AppCompatActivity {

    Button btnLogin, btnRegister;
    EditText username, password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (username.getText().toString().equals("abdul") && password.getText().toString().equals("1603")) {
                    String str = "Username = " + username.getText().toString();
                    Intent intent = new Intent(MainActivity.this, SecondActivityProfile.class);
                    intent.putExtra("Username", str);
                    intent.putExtra("Nama", "Nama = Abdul Kholiq Fajar");
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Invalid credentials",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ThirdActivityRegister.class);
                startActivity(intent);

            }
        });
    }
}